/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sistemas;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author eduro
 */
public class UsuariosDados {

    
    private static final File arquivoUsuarios = new File("usuarios.txt");

    public static void salvarUsuario(String usuario, String email, String senha) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(arquivoUsuarios, true))) {
            writer.println(usuario + ";" + email + ";" + senha);
        }
    }

    public static boolean verificarLogin(String usuario, String senha) throws IOException {
        if (!arquivoUsuarios.exists()) return false;

        try (BufferedReader reader = new BufferedReader(new FileReader(arquivoUsuarios))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] partes = linha.split(";");
                if (partes.length >= 3 && partes[0].equals(usuario) && partes[2].equals(senha)) {
                    return true;
                }
            }
        }

        return false;
    }
    
}
