/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sistemas;

/**
 *
 * @author eduro
 */
public class ContadoresDeDados {
    public static int contadorMensagens = 0;
    public static int contadorAlertas = 0;
}
